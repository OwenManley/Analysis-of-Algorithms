import java.util.Scanner;
public class GraphDriver {
	public static void main(String args[]) {
		Graph graph = new Graph(13);//Enter the number of vertices here.
		Scanner stdIn = new Scanner(System.in);
		graph.readFile("13vertices.txt");//Enter in the txt file here.
		
		System.out.println("\n\n");
		System.out.println("Creating graph...\n\n");
		System.out.println("Please enter a vertice to start at: ");
		int current = stdIn.nextInt() - 1; //Subtracting '1' because I was getting 
		//a 'IndexOutOfBounds error. 
		String input = "";
		do {
		graph.move(current);
		System.out.println("What would you like to do? (M)ove (P)rint Graph or (S)earch?: ");
		input = stdIn.next();
		
		if(input.equalsIgnoreCase("M")) {
			System.out.println("Please enter the vertex to move to: ");
			int destinationVertex = stdIn.nextInt() - 1; //Subtracting 1 because of the error.
			current = destinationVertex;
		}//end if
		else if (input.equalsIgnoreCase("P")) {
			graph.display();
		}//end else if
		
		else if (input.equalsIgnoreCase("S")){
			System.out.println("Please enter a value to search for: ");
			int finder = stdIn.nextInt();
			graph.search(graph, finder);
		}//end else if
		}while (!input.equalsIgnoreCase("E"));
		stdIn.close();
		//System.out.println();
}//end main
}//end GraphDriver