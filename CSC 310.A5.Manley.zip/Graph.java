import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Scanner;
import java.util.LinkedList;
/*Owen Manley, CSC 310, Project #3. This project constructs a graph from the given vertices and allows the users
 * to do multiple things to the trees. Mainly being traversing between vertices, printing the graph, or searching 
 * for a value in the graph.
 */
public class Graph {
	private final int V;
	private ArrayList<Integer>[] adj;
	private boolean[] marked;
	private int[] edgeTo;
	private int[] distTo;
	
	public Graph(int V) {
		this.V = V;
		adj = (ArrayList<Integer>[]) new ArrayList[V];
		for (int v = 0; v < V; v++)
			adj[v] = new ArrayList<Integer>();
	}//end Graph constructor
	
	public void addEdge(int v, int w) {
		if(v >= 0 && v < V && w >= 0 && w < V) {
		adj[v].add(w);
		adj[w].add(v);
		}//end if 
		else {
			System.out.println("Invalid vertex indices: " + v + ", " + w);
		}//end else
	}//end addEdge
	
	public Iterable<Integer> adj(int v)
	{ return adj[v]; }
	
	public void display() {
		System.out.println("Graph:\n");
		for (int v = 0; v < V; v++) {
			System.out.print((v + 1) + ": ");
			for (int i = 0; i < adj[v].size(); i++) {
				System.out.print((adj[v].get(i) + 1));
				if (i < adj[v].size() - 1) {
					System.out.print(", ");
				}//end if
			}//end inner for
			System.out.println();
		}//end outer for
	}//end display
	
	public boolean search(Graph G, int finder) {
		Queue<Integer> q = new LinkedList<>();
		boolean[] marked = new boolean[G.V];
		int[] distTo = new int[G.V];
		int[] edgeTo = new int[G.V];
		q.add(finder);
		marked[finder] = true;
		distTo[finder] = 0;
		
		while (!q.isEmpty()) {
			int v = q.poll();
			for (int w : G.adj(v)) {
				if(!marked[w]) {
					q.add(w);
					marked[w] = true;
					edgeTo[w] = v;
					distTo[w] = distTo[v] + 1;
				}
			}
		}
		while (true){
		for(int v = 0; v < G.V; v++) {
			if(marked[v]) 
			{System.out.println("Vertex " + finder + " was found in the graph."); return true;}
			System.out.println("Vertex " + finder + " was not found in the graph."); return false;
		}
		}
		}
	
	public void move(int current) {
		if(current < 0 || current >= V) {
			System.out.println("Vertex doesn't exist. Please enter a valid vertex.\n");
			return;
		}
		System.out.println("Currently at vertex: " + (current + 1) + ". Adjacent vertices: ");
		boolean temp = true;
		for (int adjVertex : adj(current)) {
			if(!temp) {
				System.out.print(", ");
			}
			else {
				temp = false;
			}
			System.out.print((adjVertex + 1));
		}//end for
		System.out.println();
	}
	
	public void readFile(String file) {

		try {
		Scanner reader = new Scanner(new File(file)); //Used to read the file.
		while(reader.hasNextLine()) {
			if(reader.hasNextInt()) {
				int v = reader.nextInt();
				if(reader.hasNextInt()) {
					int w = reader.nextInt();
					addEdge(v, w);
				}else {
					System.out.println("Invalid input: Missing second integer for edge.");
					break;
				}
			}else {
				System.out.println("Missing first integer for edge.");
				break;
			}			
		}//end while
		reader.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error: File does not exist."); //Print error if file does not exist.
			return;
		}//end catch
	}//end readFile
}//end Graph
