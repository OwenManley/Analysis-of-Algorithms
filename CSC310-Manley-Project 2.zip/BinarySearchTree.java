/*Owen Manley, CSC 310, Project #2, 03/09/2024.
 * This project reads a file of words and creates a binary search tree with them. Thus, creating a library
 * that the user can search through to find words.
 * The user must enter which file they want to read in the code before running.
 * I had to look a few things up on the internet; specifically how the scanner reads from the file. So, that
 * part is a bit funky.
 * The methods are primarily from the book, except the main method.
 */
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException; 
public class BinarySearchTree {
	private Node root; //Root for tree.
	//Creating a private class to create the node for the tree.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private class Node{
		private String key; //The word
		private int val; //Page number
		private Node left, right; //Whether or not the tree moves left or right.
		
		//Constructor to pass the parameters to the instance variables.
		public Node(String key, int val) {
			this.key = key;
			this.val = val;
		}//end constructor 
	}//end Node
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
		BinarySearchTree tree = new BinarySearchTree(); //Tree object.
		String input; //What the user inputs.
		Scanner stdIn = new Scanner(System.in); //Scanner used to read input.
		try {
		File myFile = new File("10words.txt"); //Change to specified text file that you want here.
		Scanner reader = new Scanner(myFile); //Scanner used to read the file.
		while(reader.hasNextLine()) {
			String dataset = reader.nextLine(); //The dataset is what the reader scans.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*This is the part I had to look up since I could not figure out how to make it print. I was 
*Having a lot of trouble with it. So, I belive the split() method is used to split an array into substrings.
*Once the tab is encountered, it creates a new substring. And each substring has two variables, the key and the
*value. Since it is a string, parseInt is needed to change it. Then, addValue is needed so that it adds the 
*variables/values to the tree.
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			String[] a = dataset.split("\t"); 
			String key = a[0];
			int value = Integer.parseInt(a[1]);
			tree.addValue(key,  value);
		}//end while
		reader.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error: File does not exist."); //Print error if file does not exist.
			return;
		}//end catch
//Printing the words in different traversals. Call the tree object and assign it to root to print the values.
		System.out.println("-Pre-order traversal-\n");
		tree.preOrderTraversal(tree.root);
		System.out.println();
		System.out.println("-In-order traversal-\n");
		tree.inOrderTraversal(tree.root);
		System.out.println();
		System.out.println("-Post-order traversal-\n");
		tree.postOrderTraversal(tree.root);
		System.out.println();
//This loop handles the main part of the program. If a word is found, print it and the page number. If not,
//Print that it wasn't found. If "exit" is inputted, terminate program.
		do {
		System.out.println("Please input a word: ");
		input = stdIn.nextLine();
		if (input.equalsIgnoreCase("exit")) { 
			System.out.println("See you soon!"); 
			break; 
		}
		int page = tree.search(input);
		if  (page != -1) {
			System.out.println("'" + input + "' was found on page " + page); 
		}	
		else {
			System.out.println("'" + input + "' was NOT found.");
		}
			} while(!input.equalsIgnoreCase("exit"));
	}//end main
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Constructor for the class. Not sure what it's function is because when I comment it the program still functions.
//But, it was a requirement so it is here anyways.
	BinarySearchTree(){
		
	}//end constructor
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void addValue(String key, int val){
		root = put(root, key, val);
	}//end addValue
//Use Recursion to add values to the tree.	
	private Node put(Node x, String key, int val) {
		if (x == null) return new Node(key, val);
		int cmp = key.compareTo(x.key);
		if (cmp < 0) x.left = put(x.left, key, val);
		else if (cmp > 0) x.right = put(x.right, key, val);
		else if (cmp == 0) x.val = val;
		return x;
	}//end put
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public int search(String searchKey) {
		Node x = root;
		while (x != null) {
			int cmp = searchKey.compareTo(x.key);
			if (cmp < 0) x = x.left;
			else if (cmp > 0) x = x.right;
			else if (cmp == 0) return x.val;
		}
		return -1;
	}//end search
	//!!!!!!!!!!!!!
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Methods for the traversals. Depending on the print statements changes the traversals.
	public void preOrderTraversal(Node x) {
		if(x != null) {
			System.out.println(x.key + ":" + x.val + " ");
			preOrderTraversal(x.left);
			preOrderTraversal(x.right);
		}//end if
	}//end preOrderTraversal
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void inOrderTraversal(Node x) {
		if(x != null) {
			inOrderTraversal(x.left);
			System.out.println(x.key + ":" + x.val + " ");
			inOrderTraversal(x.right);
		}
	}//end inOrderTraversal

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void postOrderTraversal(Node x) {
		if(x != null) {
			postOrderTraversal(x.left);
			postOrderTraversal(x.right);
			System.out.println(x.key + ":" + x.val + " ");
		}
	}//end postOrderTraversal
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
}// end BinarySearchTree
