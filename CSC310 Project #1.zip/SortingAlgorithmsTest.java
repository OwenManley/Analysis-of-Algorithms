/*Owen Manley, CSC 310, 2/13/2024, Project 1 - Establishes two sorting algorithms and tests their speed given
the appropriate datasets. For testing different datasets, you need to enter in the specified text file you want
to test on line 17.*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class SortingAlgorithmsTest {
	public static void main(String[] args) {
		ArrayList<Integer> dataList = new ArrayList<>(); //Arraylist used to store the values in from the text file.
		int input;
		Scanner stdIn = new Scanner(System.in);
		try {
		File myFile = new File("10000000.txt"); //Change to specified text file that you want here.
		Scanner reader = new Scanner(myFile); //Used to read the file.
		while(reader.hasNextLine()) {
			int dataset = reader.nextInt(); //The dataset is what the reader scans.
			dataList.add(dataset);			
		}//end while
		reader.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error: File does not exist."); //Print error if file does not exist.
			return;
		}//end catch
//Turning the values in the array list into an array of ints.
		Integer[] data = dataList.toArray(new Integer[dataList.size()]); 
		SortingAlgorithmsTest sort = new SortingAlgorithmsTest();
/*do-while loop is used for user inputing which algorithm they want, and calling the necesssary methods to perform
sorting.*/
		do {
		System.out.println("Which algorithm would you like to test? ('1' for insertion, '2' for merge, '3' to\nterminate).\n");
		input = stdIn.nextInt();
		long start = System.currentTimeMillis();		
		if(input == 1) {
			System.out.println("Sorting...");
			sort.insertionSort(data);
			long end = System.currentTimeMillis();
			long execution = end - start;
			confirmSorted(data);
			System.out.println("It took " + execution + " milliseconds.\n");
		}// end if
		
		else if(input == 2) {
			System.out.println("Sorting...");
			merge(data, new int[data.length], 0, data.length / 2, data.length - 1);
			sort.sort(data);
			long end = System.currentTimeMillis();
			long execution = end - start;
			confirmSorted(data);
			System.out.println("It took " + execution + " milliseconds.\n");
		}//end else if
		
		else if(input == 3) { 
			System.out.println("Goodbye!");
			break;
		}//end else if
		
		else {
			System.out.println("Algorithm not found. Try again.");
		}//end else
		} while(input != '1' || input != '2');
		stdIn.close();
		}//end main
//-----------------------------------------------------------------------------------------------------------------
//Method for insertion sort.	
	public void insertionSort(Integer[] data) {
		int n = data.length;
		for(int i = 0; i < n; i++) {
			for(int j = i; j> 0; j--) {
				if(less(data[j], data[j-1])) {
					exch(data, j, j-1);
				}//end if
				else break;
			}//end inner for
		}//end for
		}//end insertionSort
//-----------------------------------------------------------------------------------------------------------------	
	private static boolean less(int v, int w) {
		return v < w;
			}//end less
//-----------------------------------------------------------------------------------------------------------------	
	private void exch(Integer[] data, int i, int j) {
		int swap = data[i];
		data[i] = data[j];
		data[j] = swap;
	}//end exch
//------------------------------------------------------------------------------------------------------------------
//Method for the merging process of merge sort.
	private static void merge(Integer[] data, int[] aux, int lo, int mid, int hi) {
//For loop for copying values to sort.
		for(int k = lo; k <= hi; k++)
			{aux[k] = data[k];}
//Merging process
		int i = lo, j = mid+1;
		for(int k = lo; k <= hi; k++) {
			if(i > mid) data[k] = aux[j++];
			else if(j > hi) data[k] = aux[i++];
			else if(less(aux[j], aux[i])) data[k] = aux[j++];
			else data[k] = aux[i++];
		}//end for
	}//end merge
//------------------------------------------------------------------------------------------------------------------
//Both sorting methods are for merge sort.	
	private void sort(Integer[] data, int[] aux, int lo, int hi) {
//Sorting the values after copying and merging.
		if(hi <= lo) return;
		int mid = lo + (hi - lo)/2;
		sort(data, aux, lo, mid);
		sort(data, aux, mid+1, hi);
		merge(data, aux, lo, mid, hi);
	}//end sort
//------------------------------------------------------------------------------------------------------------------
//Second sort method for mergesort.	
	public void sort(Integer[] data) {
		int[] aux = new int[data.length];
		sort(data, aux, 0, data.length - 1);
	}//end sort
//-----------------------------------------------------------------------------------------------------------------	
//Method used to determine whether or not the dataset is now sorted or not.	
	private static boolean confirmSorted(Integer[] data) { 
		for (int i = 1; i < data.length; i++) {
			if (data[i] < data[i - 1]) {
				System.out.println("Confirmed NOT sorted.\n");
				return false;
			}//end if
		}//end for
				System.out.println("Confirmed sorted.");
				return true;
			}//end confirmSorted
}//end SortingAlgorithmsTest
